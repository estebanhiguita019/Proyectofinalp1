package co.edu.uniquindio.poo;

import java.util.ArrayList;

public class Empleado extends Usuario {
    private ArrayList<Empleado> empleados;
    public Empleado(String nombre, String username, String password) {
        super(nombre, username, password);
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }


    public Empleado buscarEmpleado(String username) {
        for (Empleado empleado : empleados) {
            if (empleado.getUsername().equals(username)) {
                return empleado;
            }
        }
        return null;  // o lanza una excepción si prefieres
    }
    
}





