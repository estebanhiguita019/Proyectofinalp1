package co.edu.uniquindio.poo;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Concesionario concesionario = new Concesionario();

        while (true) {
            System.out.println("1. Registrar vehículo");
            System.out.println("2. Registrar cliente");
            System.out.println("3. Alquilar vehículo");
            System.out.println("4. Vender vehículo");
            System.out.println("5. Comprar vehículo");
            System.out.println("6. Generar reporte");
            System.out.println("7. Ver vehículos registrados");
            System.out.println("8. Salir");

            int opcion = scanner.nextInt();
            scanner.nextLine();  // Consumir el salto de línea

            try {
                switch (opcion) {
                    case 1:
                        registrarVehiculo(concesionario, scanner);
                        break;
                    case 2:
                        registrarCliente(concesionario, scanner);
                        break;
                    case 3:
                        alquilarVehiculo(concesionario, scanner);
                        break;
                    case 4:
                        venderVehiculo(concesionario, scanner);
                        break;
                    case 5:
                        comprarVehiculo(concesionario, scanner,"empleado");
                        break;
                    case 6:
                        generarReporte(concesionario, scanner);
                        break;
              
                    case 7:
                        verVehiculos(concesionario);
                        break;
                    case 8:
                        System.out.println("Saliendo del sistema...");
                        return;
                    default:
                        System.out.println("Opción no válida, intenta de nuevo.");
                }
            } catch (RuntimeException e) {
                System.out.println("Error: " + e.getMessage());
            }
        }
    }

    private static void registrarVehiculo(Concesionario concesionario, Scanner scanner) {
        System.out.println("Ingrese los detalles del vehículo:");
        System.out.print("Marca: ");
        String marca = scanner.nextLine();
        System.out.print("Nuevo (true/false): ");
        boolean nuevo = scanner.nextBoolean();
        scanner.nextLine();  // Consumir el salto de línea
        System.out.print("id: ");
        String modelo = scanner.nextLine();
        System.out.print("Cambios: ");
        int cambios = scanner.nextInt();
        System.out.print("Velocidad Máxima: ");
        int velocidadMaxima = scanner.nextInt();
        System.out.print("Cilindraje: ");
        int cilindraje = scanner.nextInt();
        scanner.nextLine();  // Consumir el salto de línea

        // Crear y registrar el vehículo (usaremos una Moto como ejemplo)
        Vehiculo vehiculo = new Moto(marca, nuevo, modelo, cambios, velocidadMaxima, cilindraje);
        concesionario.registrarVehiculo(vehiculo);
        System.out.println("Vehículo registrado exitosamente.");
    }

    private static void registrarCliente(Concesionario concesionario, Scanner scanner) {
        System.out.println("Ingrese los detalles del cliente:");
        System.out.print("Nombre: ");
        String nombre = scanner.nextLine();
        System.out.print("Documento: ");
        String documento = scanner.nextLine();
        System.out.print("Dirección: ");
        String direccion = scanner.nextLine();
        System.out.print("Teléfono: ");
        String telefono = scanner.nextLine();

        Cliente cliente = new Cliente(nombre, documento, direccion, telefono);
        concesionario.registrarCliente(cliente);
        System.out.println("Cliente registrado exitosamente.");
    }

    private static void alquilarVehiculo(Concesionario concesionario, Scanner scanner) {
        System.out.println("Ingrese el documento del cliente:");
        String documento = scanner.nextLine();
        Cliente cliente;
        try {
            cliente = concesionario.buscarCliente(documento);
        } catch (RuntimeException e) {
            System.out.println(e.getMessage());
            return;
        }

        System.out.println("Ingrese el modelo del vehículo a alquilar:");
        String modelo = scanner.nextLine();
        Vehiculo vehiculo;
        try {
            vehiculo = concesionario.buscarVehiculo(modelo);
        } catch (RuntimeException e) {
            System.out.println(e.getMessage());
            return;
        }

        System.out.print("Ingrese la fecha (dd/MM/yyyy): ");
        String fecha = scanner.nextLine();
        
        concesionario.alquilarVehiculo(cliente, vehiculo, "empleado", fecha);  // Suponemos el nombre del empleado
        System.out.println("Vehículo alquilado exitosamente.");
    }

    private static void venderVehiculo(Concesionario concesionario, Scanner scanner) {
        System.out.println("Ingrese el documento del cliente:");
        String documento = scanner.nextLine();
        Cliente cliente;
        try {
            cliente = concesionario.buscarCliente(documento);
        } catch (RuntimeException e) {
            System.out.println(e.getMessage());
            return;
        }

        System.out.println("Ingrese el id del vehículo a vender:");
        String modelo = scanner.nextLine();
        Vehiculo vehiculo;
        try {
            vehiculo = concesionario.buscarVehiculo(modelo);
        } catch (RuntimeException e) {
            System.out.println(e.getMessage());
            return;
        }

        System.out.print("Ingrese la fecha (dd/MM/yyyy): ");
        String fecha = scanner.nextLine();

        concesionario.venderVehiculo(cliente, vehiculo, "empleado", fecha);  // Suponemos el nombre del empleado
        System.out.println("Vehículo vendido exitosamente.");
    }

    private static void comprarVehiculo(Concesionario concesionario, Scanner scanner, String usuario) {
        concesionario.comprarVehiculo(usuario);
    }
    
    


 

    private static void generarReporte(Concesionario concesionario, Scanner scanner) {
        System.out.print("Ingrese la fecha de inicio (dd/MM/yyyy): ");
        String fechaInicio = scanner.nextLine();
        System.out.print("Ingrese la fecha de fin (dd/MM/yyyy): ");
        String fechaFin = scanner.nextLine();
    
        ArrayList<Transaccion> reporte = concesionario.generarReporte(fechaInicio, fechaFin);
        System.out.println("Reporte de transacciones:");
        for (Transaccion transaccion : reporte) {
            System.out.println("Fecha: " + transaccion.getFecha());
            System.out.println("Tipo: " + transaccion.getTipo());
            System.out.println("Empleado: " + transaccion.getEmpleado());
            System.out.println("Cliente: " + transaccion.getCliente().getNombre());
            System.out.println("Vehículo: " + transaccion.getVehiculo().getModelo());
            System.out.println("-----------------------");
        }
    }
    public static void verVehiculos(Concesionario concesionario) { concesionario.verVehiculos(); }

    
        
    }