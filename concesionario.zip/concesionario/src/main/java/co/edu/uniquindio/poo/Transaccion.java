package co.edu.uniquindio.poo;



public class Transaccion {
    private Cliente cliente;
    private Vehiculo vehiculo;
    private String tipo; // Puede ser "compra", "venta" o "alquiler"
    private String empleado;
    private String fecha;

    public Transaccion(Cliente cliente, Vehiculo vehiculo, String tipo, String empleado, String fecha) {
        this.cliente = cliente;
        this.vehiculo = vehiculo;
        this.tipo = tipo;
        this.empleado = empleado;
        this.fecha = fecha;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public Vehiculo getVehiculo() {
        return vehiculo;
    }

    public String getTipo() {
        return tipo;
    }

    public String getEmpleado() {
        return empleado;
    }

    public String getFecha() {
        return fecha;
    }
}





