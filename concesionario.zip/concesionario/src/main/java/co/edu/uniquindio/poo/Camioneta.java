package co.edu.uniquindio.poo;

public class Camioneta extends Vehiculo {
    private boolean traccionCuatroRuedas; // Indica si la camioneta tiene tracción en las cuatro ruedas
    private double capacidadCarga; // Capacidad de carga en kilogramos

    public Camioneta(String marca, boolean nuevo, String modelo, int cambios, int velocidadMaxima, int cilindraje, boolean traccionCuatroRuedas, double capacidadCarga) {
        super(marca, nuevo, modelo, cambios, velocidadMaxima, cilindraje);
        this.traccionCuatroRuedas = traccionCuatroRuedas;
        this.capacidadCarga = capacidadCarga;
    }

    public boolean isTraccionCuatroRuedas() {
        return traccionCuatroRuedas;
    }

    public void setTraccionCuatroRuedas(boolean traccionCuatroRuedas) {
        this.traccionCuatroRuedas = traccionCuatroRuedas;
    }

    public double getCapacidadCarga() {
        return capacidadCarga;
    }

    public void setCapacidadCarga(double capacidadCarga) {
        this.capacidadCarga = capacidadCarga;
    }

    @Override
    public void mostrarDetalles() {
        super.mostrarDetalles();
        System.out.println("Tracción en Cuatro Ruedas: " + (traccionCuatroRuedas ? "Sí" : "No"));
        System.out.println("Capacidad de Carga: " + capacidadCarga + " kg");
    }
}



