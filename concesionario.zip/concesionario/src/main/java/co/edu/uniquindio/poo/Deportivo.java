package co.edu.uniquindio.poo;

public class Deportivo extends Vehiculo {
    private int caballosDeFuerza;
    private boolean tieneTurbo;

    public Deportivo(String marca, boolean nuevo, String modelo, int cambios, int velocidadMaxima, int cilindraje, int caballosDeFuerza, boolean tieneTurbo) {
        super(marca, nuevo, modelo, cambios, velocidadMaxima, cilindraje);
        this.caballosDeFuerza = caballosDeFuerza;
        this.tieneTurbo = tieneTurbo;
    }

    public int getCaballosDeFuerza() {
        return caballosDeFuerza;
    }

    public void setCaballosDeFuerza(int caballosDeFuerza) {
        this.caballosDeFuerza = caballosDeFuerza;
    }

    public boolean isTieneTurbo() {
        return tieneTurbo;
    }

    public void setTieneTurbo(boolean tieneTurbo) {
        this.tieneTurbo = tieneTurbo;
    }

    @Override
    public void mostrarDetalles() {
        super.mostrarDetalles();
        System.out.println("Caballos de Fuerza: " + caballosDeFuerza);
        System.out.println("Tiene Turbo: " + (tieneTurbo ? "Sí" : "No"));
    }
}
