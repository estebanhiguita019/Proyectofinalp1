package co.edu.uniquindio.poo;
public class Moto extends Vehiculo {
    private boolean tieneCasco;
    private boolean tieneMaletero;

    public Moto(String marca, boolean nuevo, String modelo, int cambios, int velocidadMaxima, int cilindraje) {
        super(marca, nuevo, modelo, cambios, velocidadMaxima, cilindraje);
        this.tieneCasco = false; // Por defecto no incluye casco
        this.tieneMaletero = false; // Por defecto no incluye maletero
    }

    public boolean tieneCasco() {
        return tieneCasco;
    }

    public void setTieneCasco(boolean tieneCasco) {
        this.tieneCasco = tieneCasco;
    }

    public boolean tieneMaletero() {
        return tieneMaletero;
    }

    public void setTieneMaletero(boolean tieneMaletero) {
        this.tieneMaletero = tieneMaletero;
    }

    @Override
    public void mostrarDetalles() {
        super.mostrarDetalles();
        System.out.println("Tiene Casco: " + (tieneCasco ? "Sí" : "No"));
        System.out.println("Tiene Maletero: " + (tieneMaletero ? "Sí" : "No"));
    }
}

