package co.edu.uniquindio.poo;

public class Sedan extends Vehiculo {
    private String tipo; // Por ejemplo: compacto, mediano, grande, etc.
    private String eficiencia; // Por ejemplo: combustible, híbrido, eléctrico

    public Sedan(String marca, boolean nuevo, String modelo, int cambios, int velocidadMaxima, int cilindraje, String tipo, String eficiencia) {
        super(marca, nuevo, modelo, cambios, velocidadMaxima, cilindraje);
        this.tipo = tipo;
        this.eficiencia = eficiencia;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getEficiencia() {
        return eficiencia;
    }

    public void setEficiencia(String eficiencia) {
        this.eficiencia = eficiencia;
    }

    @Override
    public void mostrarDetalles() {
        super.mostrarDetalles();
        System.out.println("Tipo: " + tipo);
        System.out.println("Eficiencia: " + eficiencia);
    }

}



