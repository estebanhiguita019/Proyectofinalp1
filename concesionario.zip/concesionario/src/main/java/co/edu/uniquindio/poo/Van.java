
package co.edu.uniquindio.poo;

public class Van extends Vehiculo {
    private int capacidadPasajeros; // Número de pasajeros que puede transportar
    private double capacidadCarga; // Capacidad de carga en kilogramos

    public Van(String marca, boolean nuevo, String modelo, int cambios, int velocidadMaxima, int cilindraje, int capacidadPasajeros, double capacidadCarga) {
        super(marca, nuevo, modelo, cambios, velocidadMaxima, cilindraje);
        this.capacidadPasajeros = capacidadPasajeros;
        this.capacidadCarga = capacidadCarga;
    }

    public int getCapacidadPasajeros() {
        return capacidadPasajeros;
    }

    public void setCapacidadPasajeros(int capacidadPasajeros) {
        this.capacidadPasajeros = capacidadPasajeros;
    }

    public double getCapacidadCarga() {
        return capacidadCarga;
    }

    public void setCapacidadCarga(double capacidadCarga) {
        this.capacidadCarga = capacidadCarga;
    }

    @Override
    public void mostrarDetalles() {
        super.mostrarDetalles();
        System.out.println("Capacidad de Pasajeros: " + capacidadPasajeros);
        System.out.println("Capacidad de Carga: " + capacidadCarga + " kg");
    }
}

