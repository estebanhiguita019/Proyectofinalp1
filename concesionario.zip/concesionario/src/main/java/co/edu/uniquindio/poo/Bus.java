package co.edu.uniquindio.poo;

public class Bus extends Vehiculo {
    private int capacidadPasajeros; // Número de pasajeros que puede transportar
    private boolean servicioIntermunicipal; // Indica si el bus es para servicio intermunicipal

    public Bus(String marca, boolean nuevo, String modelo, int cambios, int velocidadMaxima, int cilindraje, int capacidadPasajeros, boolean servicioIntermunicipal) {
        super(marca, nuevo, modelo, cambios, velocidadMaxima, cilindraje);
        this.capacidadPasajeros = capacidadPasajeros;
        this.servicioIntermunicipal = servicioIntermunicipal;
    }

    public int getCapacidadPasajeros() {
        return capacidadPasajeros;
    }

    public void setCapacidadPasajeros(int capacidadPasajeros) {
        this.capacidadPasajeros = capacidadPasajeros;
    }

    public boolean isServicioIntermunicipal() {
        return servicioIntermunicipal;
    }

    public void setServicioIntermunicipal(boolean servicioIntermunicipal) {
        this.servicioIntermunicipal = servicioIntermunicipal;
    }

    @Override
    public void mostrarDetalles() {
        super.mostrarDetalles();
        System.out.println("Capacidad de Pasajeros: " + capacidadPasajeros);
        System.out.println("Servicio Intermunicipal: " + (servicioIntermunicipal ? "Sí" : "No"));
    }
}
