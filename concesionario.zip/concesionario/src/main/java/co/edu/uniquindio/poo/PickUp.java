package co.edu.uniquindio.poo;

public class PickUp extends Vehiculo {
    private String tipoCabina; // Por ejemplo: simple, doble
    private double capacidadCarga; // Capacidad de carga en kilogramos

    public PickUp(String marca, boolean nuevo, String modelo, int cambios, int velocidadMaxima, int cilindraje, String tipoCabina, double capacidadCarga) {
        super(marca, nuevo, modelo, cambios, velocidadMaxima, cilindraje);
        this.tipoCabina = tipoCabina;
        this.capacidadCarga = capacidadCarga;
    }

    public String getTipoCabina() {
        return tipoCabina;
    }

    public void setTipoCabina(String tipoCabina) {
        this.tipoCabina = tipoCabina;
    }

    public double getCapacidadCarga() {
        return capacidadCarga;
    }

    public void setCapacidadCarga(double capacidadCarga) {
        this.capacidadCarga = capacidadCarga;
    }

    @Override
    public void mostrarDetalles() {
        super.mostrarDetalles();
        System.out.println("Tipo de Cabina: " + tipoCabina);
        System.out.println("Capacidad de Carga: " + capacidadCarga + " kg");
    }
}

