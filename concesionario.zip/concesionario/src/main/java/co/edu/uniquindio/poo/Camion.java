package co.edu.uniquindio.poo;

public class Camion extends Vehiculo {
    private double capacidadCarga; // Capacidad de carga en kilogramos
    private int numeroEjes; // Número de ejes del camión

    public Camion(String marca, boolean nuevo, String modelo, int cambios, int velocidadMaxima, int cilindraje, double capacidadCarga, int numeroEjes) {
        super(marca, nuevo, modelo, cambios, velocidadMaxima, cilindraje);
        this.capacidadCarga = capacidadCarga;
        this.numeroEjes = numeroEjes;
    }

    public double getCapacidadCarga() {
        return capacidadCarga;
    }

    public void setCapacidadCarga(double capacidadCarga) {
        this.capacidadCarga = capacidadCarga;
    }

    public int getNumeroEjes() {
        return numeroEjes;
    }

    public void setNumeroEjes(int numeroEjes) {
        this.numeroEjes = numeroEjes;
    }

    @Override
    public void mostrarDetalles() {
        super.mostrarDetalles();
        System.out.println("Capacidad de Carga: " + capacidadCarga + " kg");
        System.out.println("Número de Ejes: " + numeroEjes);
    }
}


