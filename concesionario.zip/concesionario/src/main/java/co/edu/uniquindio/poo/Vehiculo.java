package co.edu.uniquindio.poo;

public  class  Vehiculo {
    private String marca;
    private boolean nuevo;
    private String modelo;
    private int cambios;
    private int velocidadMaxima;
    private int cilindraje;
    private String registradoPor;

    public Vehiculo(String marca, boolean nuevo, String modelo, int cambios, int velocidadMaxima, int cilindraje) {
        this.marca = marca;
        this.nuevo = nuevo;
        this.modelo = modelo;
        this.cambios = cambios;
        this.velocidadMaxima = velocidadMaxima;
        this.cilindraje = cilindraje;
    }

    public String getRegistradoPor() {
        return registradoPor;
    }

    public void setRegistradoPor(String registradoPor) {
        this.registradoPor = registradoPor;
    }

    public void mostrarDetalles() {
        System.out.println("Marca: " + marca);
        System.out.println("Nuevo: " + (nuevo ? "Sí" : "No"));
        System.out.println("ID: " + modelo);
        System.out.println("Cambios: " + cambios);
        System.out.println("Velocidad Máxima: " + velocidadMaxima + " km/h");
        System.out.println("Cilindraje: " + cilindraje + " cc");
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public boolean isNuevo() {
        return nuevo;
    }

    public void setNuevo(boolean nuevo) {
        this.nuevo = nuevo;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public int getCambios() {
        return cambios;
    }

    public void setCambios(int cambios) {
        this.cambios = cambios;
    }

    public int getVelocidadMaxima() {
        return velocidadMaxima;
    }

    public void setVelocidadMaxima(int velocidadMaxima) {
        this.velocidadMaxima = velocidadMaxima;
    }

    public int getCilindraje() {
        return cilindraje;
    }

    public void setCilindraje(int cilindraje) {
        this.cilindraje = cilindraje;
    }

    

    // Otros métodos...
}



