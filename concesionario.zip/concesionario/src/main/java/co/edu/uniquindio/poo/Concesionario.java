package co.edu.uniquindio.poo;
import java.util.ArrayList;

public class Concesionario {
    private ArrayList<Vehiculo> vehiculos;
    private ArrayList<Cliente> clientes;
    private ArrayList<Transaccion> transacciones;
    private ArrayList<Empleado> empleados;

    public Concesionario() {
        vehiculos = new ArrayList<>();
        clientes = new ArrayList<>();
        transacciones = new ArrayList<>();
        empleados = new ArrayList<>();
    }

    public void registrarVehiculo(Vehiculo vehiculo) {
        vehiculos.add(vehiculo);
    }
    
    public void registrarCliente(Cliente cliente) {
        clientes.add(cliente);
    }
    
    
    
        public void alquilarVehiculo(Cliente cliente, Vehiculo vehiculo, String empleado, String fecha) {
            Transaccion transaccion = new Transaccion(cliente, vehiculo, "alquiler", empleado, fecha);
            transacciones.add(transaccion);
        }
    
        public void venderVehiculo(Cliente cliente, Vehiculo vehiculo, String empleado, String fecha) {
            Transaccion transaccion = new Transaccion(cliente, vehiculo, "venta", empleado, fecha);
            transacciones.add(transaccion);
        }
    
        public void comprarVehiculo(String usuario) {
            ArrayList<Vehiculo> vehiculosDelEmpleado = new ArrayList<>();
            for (Vehiculo vehiculo : vehiculos) {
                if (vehiculo.getRegistradoPor().equals(usuario)) {
                    vehiculosDelEmpleado.add(vehiculo);
                }
            }
        
            if (vehiculosDelEmpleado.isEmpty()) {
                System.out.println("No hay vehículos registrados por " + usuario + ".");
            } else {
                System.out.println("Vehículos registrados por " + usuario + ":");
                for (Vehiculo vehiculo : vehiculosDelEmpleado) {
                    vehiculo.mostrarDetalles();
                    System.out.println("-----------------------");
                }
            }
        }
        
        public Cliente buscarCliente(String documento) {
            for (Cliente cliente : clientes) {
                if (cliente.getDocumento().equals(documento)) {
                    return cliente;
                }
            }
            throw new RuntimeException("Cliente con documento " + documento + " no encontrado.");
        }
    
        public Vehiculo buscarVehiculo(String modelo) {
            for (Vehiculo vehiculo : vehiculos) {
                if (vehiculo.getModelo().equals(modelo)) {
                    return vehiculo;
                }
            }
            throw new RuntimeException("Vehículo con modelo " + modelo + " no encontrado.");
        }
    
        public Empleado buscarEmpleado(String username) {
            for (Empleado empleado : empleados) {
                if (empleado.getUsername().equals(username)) {
                    return empleado;
                }
            }
            return null;
        }
    
        public boolean revisionTecnica(Vehiculo vehiculo) {
            // Implementar la lógica de revisión técnica
            return true;  // Supongamos que el vehículo pasa la revisión
        }
    
        public void registrarEmpleado(Empleado empleado) {
            empleados.add(empleado);
        }
    
      
        public void bloquearEmpleado(Empleado empleado) {
            empleados.remove(empleado);  // Suponiendo que bloquear significa eliminar de la lista
        }
    
        public ArrayList<Transaccion> generarReporte(String fechaInicio, String fechaFin) {
            ArrayList<Transaccion> reporte = new ArrayList<>();
            for (Transaccion transaccion : transacciones) {
                // Supongamos que la fecha es un String en formato "dd/MM/yyyy"
                if (transaccion.getFecha().compareTo(fechaInicio) >= 0 && transaccion.getFecha().compareTo(fechaFin) <= 0) {
                    reporte.add(transaccion);
                }
            }
            return reporte;
        }
    
        public void listarVehiculos() {
            if (vehiculos.isEmpty()) {
                System.out.println("No hay vehículos registrados.");
                return;
            }
            for (Vehiculo vehiculo : vehiculos) {
                vehiculo.mostrarDetalles();
                System.out.println("-----------------------");
            }
        }
    
        public void listarVehiculosPorUsuario(String usuario) {
            boolean encontrado = false;
            for (Vehiculo vehiculo : vehiculos) {
                if (vehiculo.getRegistradoPor().equals(usuario)) {
                    vehiculo.mostrarDetalles();
                    System.out.println("-----------------------");
                    encontrado = true;
                }
            }
            if (!encontrado) {
                System.out.println("No hay vehículos registrados por " + usuario + ".");
            }
        }
    
        public void listarEmpleados() {
            if (empleados.isEmpty()) {
                System.out.println("No hay empleados registrados.");
                return;
            }
            for (Empleado empleado : empleados) {
                System.out.println("Nombre: " + empleado.getNombre());
                System.out.println("Username: " + empleado.getUsername());
                System.out.println("-----------------------");
            }
        }

        
            public void verVehiculos() {
                System.out.println("Lista de Vehículos en el Concesionario:");
                System.out.println("======================================");
                for (Vehiculo vehiculo : vehiculos) {
                    vehiculo.mostrarDetalles();
                    System.out.println("--------------------------------------");
                }
            }
        
            // Otros métodos...
        }
        
        
    
    



    
    
     
    